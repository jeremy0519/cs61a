test = {
  'name': 'using-link',
  'points': 0,
  'suites': [
      {
      'type': 'concept',
      'cases': [
        {
          'question': """
          Find the Python expression that returns a `Link` representing the given expression: (+ (- 2 4) 6 8)
          """,
          'choices': [
            "Link('+', Link('-', Link(2, Link(4, Link(6, Link(8))))))",
            "Link('+', Link(Link(-, Link(2, Link(4))), Link(6, Link(8))))",
            "Link(+, Link(Link(-, Link(2, Link(4))), Link(6, Link(8))))",
            "Link('+', Link(Link('-', Link(2, Link(4))), Link(6, Link(8))))",
            "None of these"
          ],
          'answer': "Link('+', Link(Link('-', Link(2, Link(4))), Link(6, Link(8))))",
          'hidden': False
        },
        {
        'question': """
        What is the operator of the previous part's call expression?
          """,
          'choices': [
            '-',
            '+',
            '(',
            '2',
            '6',
            'None of these'
          ],
          'answer': "+",
          'hidden': False
        },
        {
            'question': """
            If the `Link` you constructed in the previous part was bound to the name `p`,
            how would you retrieve the operator?
            """,
            'choices': [
            'p',
            'p.first',
            'p.rest',
            'p.rest.first',
            'p.first.rest'
            ],
            'answer': "p.first",
            'hidden': False
        },
        {
        'question': """
        If the `Link` you constructed was bound to the name `p`, 
        how would you retrieve a list containing all of the operands?
          """,
          'choices': [
            'p',
            'p.first',
            'p.rest',
            'p.rest.first',
            'p.first.rest'
            ],
          'answer': "p.rest",
          'hidden': False
        },
        {
        'question': """
        How would you retrieve only the first operand?
          """,
          'choices': [
            'p',
            'p.first',
            'p.rest',
            'p.rest.first',
            'p.first.rest'
            ],
          'answer': "p.rest.first",
          'hidden': False
        },
        {
        'question': """
        What is the first operand of the call expression (+ (- 2 4) 6 8) prior to evaluation?
          """,
          'choices': [
            "'-'",
            "'+'",
            "2",
            "4",
            "-2",
            "Link('-', Link(2, Link(4)))",
            "Link(2, Link(4))"
            ],
          'answer': "Link('-', Link(2, Link(4)))",
          'hidden': False
        }
      ]
    }
    ]
}