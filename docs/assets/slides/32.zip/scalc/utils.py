"Utility functions"

from scheme_reader import Link, nil

def reduce(fn, scheme_list, start):
    """Reduce a recursive list of Links using fn and a start value.

    >>> reduce(add, as_scheme_list(1, 2, 3), 0)
    6
    """
    if scheme_list is nil:
        return start
    return reduce(fn, scheme_list.rest, fn(start, scheme_list.first))